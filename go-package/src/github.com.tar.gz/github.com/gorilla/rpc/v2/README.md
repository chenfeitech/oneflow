rpc
===

gorilla/rpc is a foundation for RPC over HTTP services, providing access to the exported methods of an object through HTTP requests.

Read the full documentation here: http://www.gorillatoolkit.org/pkg/rpc
