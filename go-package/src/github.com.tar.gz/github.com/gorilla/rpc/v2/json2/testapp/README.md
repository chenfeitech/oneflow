Counter (TestApp)
=================

1) Build

    $ go build counter.go
    $ ./counter


2) Navigate to localhost:65534 on the browser to access the app.
